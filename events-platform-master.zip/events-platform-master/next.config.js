module.exports = {
  reactStrictMode: true,
  images: {
    domains: [
      'lh3.googleusercontent.com',
      'images.pexels.com',
      'cdn.pixabay.com',
    ],
  },
};
